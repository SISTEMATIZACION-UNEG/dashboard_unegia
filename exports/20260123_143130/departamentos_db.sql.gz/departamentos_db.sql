--
-- PostgreSQL database dump
--

\restrict 1j6UeJuMspGFPl7fcWslGatGRuruykh4379KW9PR4OYE9BQiGZHt0FQ5St6JiQX

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: correos_enviados; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.correos_enviados (
    id integer NOT NULL,
    reporte_id integer,
    cedula character varying(20) NOT NULL,
    destinatario character varying(100) NOT NULL,
    asunto character varying(150) NOT NULL,
    mensaje text,
    foto_path character varying(255),
    estatus_confirmacion boolean DEFAULT false,
    fecha_envio timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    fecha_confirmacion timestamp without time zone,
    estatus_solucion boolean DEFAULT false
);


--
-- Name: correos_enviados_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.correos_enviados_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: correos_enviados_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.correos_enviados_id_seq OWNED BY public.correos_enviados.id;


--
-- Name: jefes_departamento; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jefes_departamento (
    id integer NOT NULL,
    nombre_jefe character varying(100) NOT NULL,
    departamento character varying(100) NOT NULL,
    correo_electronico character varying(150) NOT NULL,
    telefono character varying(20),
    trial226 character(1),
    cedula character varying(20)
);


--
-- Name: jefes_departamento_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.jefes_departamento_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jefes_departamento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.jefes_departamento_id_seq OWNED BY public.jefes_departamento.id;


--
-- Name: correos_enviados id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.correos_enviados ALTER COLUMN id SET DEFAULT nextval('public.correos_enviados_id_seq'::regclass);


--
-- Name: jefes_departamento id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jefes_departamento ALTER COLUMN id SET DEFAULT nextval('public.jefes_departamento_id_seq'::regclass);


--
-- Data for Name: correos_enviados; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.correos_enviados (id, reporte_id, cedula, destinatario, asunto, mensaje, foto_path, estatus_confirmacion, fecha_envio, fecha_confirmacion, estatus_solucion) FROM stdin;
1	\N	19905671	acalcurian671@gmail.com	Nuevo Reporte Registrado	aja jaja jaja	uploads/19905671_dispensador_de_agua.jpg	f	2025-11-12 18:50:45.527872	\N	f
2	\N	19905671	acalcurian671@gmail.com	Nuevo Reporte Registrado	aki aki 2	uploads/19905671_mantenimiento.png	t	2025-11-12 19:24:31.453879	\N	f
3	\N	19905672	acalcurian671@gmail.com	Nuevo Reporte Registrado	problema nueva	uploads/19905672_problema_aire.jpg	t	2025-11-12 20:05:50.208511	\N	f
5	\N	19905671	acalcurian671@gmail.com	Nuevo Reporte Registrado	adasdasdsad	uploads/19905671_nevera.jpg	t	2025-11-13 11:41:49.757612	\N	t
4	\N	19905671	acalcurian671@gmail.com	Nuevo Reporte Registrado	dañada	uploads/19905671_nevera.jpg	f	2025-11-13 11:31:26.854214	\N	t
6	\N	19905671	acalcurian671@gmail.com	Nuevo Reporte Registrado	el callao	uploads/19905671_dashboard.jpg	f	2025-11-15 07:02:56.194848	\N	t
7	\N	19905671	acalcurian671@gmail.com	Nuevo Reporte Registrado	se daño bombillo	uploads/19905671_luminaria_danada.jpg	t	2025-11-25 19:11:06.085394	\N	f
8	\N	199056715	acalcurian671@gmail.com	Nuevo Reporte Registrado	prueba ubicacion	uploads/199056715_cableado_expuesto.jpg	f	2025-11-27 13:31:32.407097	\N	f
9	\N	19905671	acalcurian671@gmail.com	Nuevo Reporte Registrado	prueba sin ubicacion	uploads/19905671_regleta_en_llamas.jpg	f	2025-11-28 16:58:45.077689	\N	f
10	\N	19905671	acalcurian671@gmail.com	Nuevo Reporte Registrado	otra vez	uploads/19905671_photo_2025-11-29_07-26-23.jpg	f	2025-11-29 11:57:35.282888	\N	f
11	\N	19905671	acalcurian671@gmail.com	Nuevo Reporte Registrado	nuevamente	uploads/19905671_20251129_114956.jpg	f	2025-11-29 16:06:39.486704	\N	f
12	\N	10393317	acalcurian671@gmail.com	Nuevo Reporte Registrado	intentando guardar	uploads/10393317_insumos_electricos.jpg	f	2025-11-29 19:17:57.667741	\N	f
13	\N	19905671	acalcurian671@gmail.com	Nuevo Reporte Registrado	impresora sin tinta en piso 2 modulo 1	uploads/19905671_tinte_impresora.jpg	f	2026-01-22 15:02:18.467514	\N	f
14	\N	19905671	acalcurian671@gmail.com	Nuevo Reporte Registrado	bombillo quemado	uploads/19905671_bombillos.jpg	f	2026-01-23 11:51:23.899769	\N	f
\.


--
-- Data for Name: jefes_departamento; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jefes_departamento (id, nombre_jefe, departamento, correo_electronico, telefono, trial226, cedula) FROM stdin;
1	Angelo Calcurian	Servicios Generales	dondecoco5@gmail.com	04240000000	T	19905671
\.


--
-- Name: correos_enviados_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.correos_enviados_id_seq', 14, true);


--
-- Name: jefes_departamento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.jefes_departamento_id_seq', 1, true);


--
-- Name: correos_enviados correos_enviados_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.correos_enviados
    ADD CONSTRAINT correos_enviados_pkey PRIMARY KEY (id);


--
-- Name: jefes_departamento pk_jefes_departamento; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jefes_departamento
    ADD CONSTRAINT pk_jefes_departamento PRIMARY KEY (id);


--
-- Name: idx_correo_electronico; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_correo_electronico ON public.jefes_departamento USING btree (correo_electronico);


--
-- PostgreSQL database dump complete
--

\unrestrict 1j6UeJuMspGFPl7fcWslGatGRuruykh4379KW9PR4OYE9BQiGZHt0FQ5St6JiQX

